
void teste()
{
   struct sockaddr_in server;

   int ssd = socket(AF_INET, SOCK_STREAM, 0);
   if(ssd < 0) {
      printf("Erro ao criar socket.");
      return;
   }

   memset(&server, 0, sizeof(server));

   server.sin_family = AF_INET;
   server.sin_addr.s_addr = INADDR_ANY;
   server.sin_port = htons(8888);

   if(bind(ssd, (struct sockaddr *)&server, sizeof(server)) < 0) {
      printf("Erro ao associar socket.\n");
      close(ssd);
      return;
   }

   for(;;) {
      int res = listen(ssd, 1);
      if(res < 0) {
         printf("Erro ao entrar no estado listen\n");
         close(ssd);
         return;
      }

      struct sockaddr_in client;
      socklen_t length;

      int csd = accept(ssd, (struct sockaddr *)&client, &length);
      if(csd < 0) {
         printf("Erro ao aceitar conexão.\n");
         close(ssd);
         return;
      }

      int n = write(csd, "Hi There!\n", 10);
      if(n < 0) {
         printf("Erro ao enviar dados.\n");
         close(csd);
         close(ssd);
         return;
      }

      close(csd);
   }
}

void teste2()
{
   struct addrinfo hints;
   struct addrinfo *res, *r;
   char str[80];

   memset(&hints, 0, sizeof(hints));
   hints.ai_family = AF_INET;
   hints.ai_socktype = SOCK_STREAM;
   hints.ai_flags = AI_PASSIVE;

   int s = getaddrinfo("www.google.com", NULL, &hints, &res);
   if (s != 0) {
                  printf("getaddrinfo: %s\n", gai_strerror(s));
                  return;
              }

   for(r=res; r!=NULL; r=r->ai_next) {
      sockaddr_in *a = (sockaddr_in*)r->ai_addr;
      inet_ntop(AF_INET, &a->sin_addr, str, 80);
      printf("%s\n", str);
   }

   printf("Pronto.\n");
}

void
testa_socket_server()
{
   char buf[80];
   TCPServer server(8888);
   for(;;) {
      TCPClient *cliente = server.listen();
      if(cliente != NULL) {
         cliente->write((void*)"Manda!\n", 7);
         int n = cliente->read(buf, sizeof(buf));
         cliente->write(buf, n);
         cliente->close();

         delete cliente;
      }
   }
}

void testa_client_socket()
{
   char buf[400];
   TCPClient cliente;
   if(cliente.connect("192.168.1.10", 22)) {
      printf("Conectado...\n");
      int n = cliente.read(buf, sizeof(buf));
      buf[n] = 0;
      printf("Recebido:\n%s\n", buf);
      cliente.close();
   } else printf("Não conectou....\n");
}
