
#include "mrf24j40.h"
#include <string.h>
#include <stdexcept>
#include "config.h"
using namespace std;

/*
 * Registradores Short.
 */
#define RXMCR                 0x00
#define PANIDL                0x01
#define PANIDH                0x02
#define SADRL                 0x03
#define SADRH                 0x04
#define EADR0                 0x05
#define EADR1                 0x06
#define EADR2                 0x07
#define EADR3                 0x08
#define EADR4                 0x09
#define EADR5                 0x0a
#define EADR6                 0x0b
#define EADR7                 0x0c
#define RXFLUSH               0x0d
#define TXSTATE0              0x0e
#define TXSTATE1              0x0f
#define ORDER                 0x10
#define TXMCR                 0x11
#define ACKTMOUT              0x12
#define ESLOTG1               0x13
#define SYMTICKL              0x14
#define SYMTICKH              0x15
#define PACON0                0x16
#define PACON1                0x17
#define PACON2                0x18
#define CSMACR                0x19
#define TXBCON0               0x1a
#define TXNCON                0x1b
#define TXG1CON               0x1c
#define TXG2CON               0x1d
#define ESLOTG23              0x1e
#define ESLOTG45              0x1f
#define ESLOTG67              0x20
#define TXPEND                0x21
#define WAKECON               0x22
#define FRMOFFSET             0x23
#define TXSTAT                0x24
#define TXBCON1               0x25
#define GATECLK               0x26
#define TXOTIME               0x27
#define HSYMTMRL              0x28
#define HSYMTMRH              0x29
#define SOFTRST               0x2a
#define BISTCR                0x2b
#define SECCON0               0x2c
#define SECCON1               0x2d
#define TXSTBL                0x2e
#define SECISR                0x2f
#define RXSR                  0x30
#define INTSTAT               0x31
#define INT_CON               0x32
#define GPIO_R                0x33
#define TRISGPIO              0x34
#define SLPACK                0x35
#define RFCTL                 0x36
#define SECCR2                0x37
#define BBREG0                0x38
#define BBREG1                0x39
#define BBREG2                0x3a
#define BBREG3                0x3b
#define BBREG4                0x3c
#define BBREG5                0x3d
#define BBREG6                0x3e
#define CCAEDTH               0x3f

/*
 * Registradores Long.
 */
#define RFCON0                0x200
#define RFCON1                0x201
#define RFCON2                0x202
#define RFCON3                0x203
#define RFCON4                0x204
#define RFCON5                0x205
#define RFCON6                0x206
#define RFCON7                0x207
#define RFCON8                0x208
#define SLPCAL0               0x209
#define SLPCAL1               0x20a
#define SLPCAL2               0x20b
#define SFCNTRH               0x20c
#define SFCNTRM               0x20d
#define SFCNTRL               0x20e
#define RFSTATE               0x20f
#define RSSI                  0x210
#define SLPCON0               0x211
#define SRCADRMODE            0x212
#define SRCADDR0              0x213
#define SRCADDR1              0x214
#define SRCADDR2              0x215
#define SRCADDR3              0x216
#define SRCADDR4              0x217
#define SRCADDR5              0x218
#define SRCADDR6              0x219
#define SRCADDR7              0x21a
#define RXFRAMESTATE          0x21b
#define SECSTATUS             0x21c
#define STCCMP                0x21d
#define HLEN                  0x21e
#define FLEN                  0x21f
#define SLPCON1               0x220
#define WAKETIMEL             0x222
#define WAKETIMEH             0x223
#define REMCNTL               0x224
#define REMCNTH               0x225
#define MAINCNT0              0x226
#define MAINCNT1              0x227
#define MAINCNT2              0x228
#define MAINCNT3              0x229
#define RFMANUALCTRLEN        0x22a
#define RFMANUALCTRL          0x22b
#define RFRXCTRL RFMANUALCTRL
#define TxDACMANUALCTRL       0x22c
#define RFMANUALCTRL2         0x22d
#define TESTRSSI              0x22e
#define TESTMODE              0x22f

/*
 * Bits de ISRSTS.
 */
#define ISR_RXIF              3
#define ISR_TXIF              0
#define ISR_WAKEIF            6

#define MAX_PCKT_SIZE         127

/**
 * Altera o valor do registrador do MRF24J40.
 * @param reg Endereço do registrador (0x00 a 0x3f).
 * @param v Valor a escrever.
 */
void
MRF24::write_short(uint8_t reg, uint8_t val)
{
   cs.reset();
   spi.putc(reg << 1 | 0x01);
   spi.putc(val);
   cs.set();
}

/**
 * Retorna o valor atual do registrador do MRF24J40.
 * @param reg Endereço do registrador (0x00 a 0x3f).
 * @return Valor atual do registrador.
 */
uint8_t
MRF24::read_short(uint8_t reg)
{
   cs.reset();
   spi.putc(reg << 1);
   uint8_t res = spi.getc();
   cs.set();
   return res;
}

/**
 * Altera o valor do registrador do MRF24J40.
 * @param reg Endereço do registrador (0x00 a 0x3ff).
 * @param v Valor a escrever.
 */
void
MRF24::write_long(uint16_t reg, uint8_t val)
{
   reg = (reg << 5) | 0x8010;
   cs.reset();
   spi.putc(reg >> 8);
   spi.putc(reg & 0xff);
   spi.putc(val);
   cs.set();
}

/**
 * Retorna o valor atual do registrador do MRF24J40.
 * @param reg Endereço do registrador (0x00 a 0x3ff).
 * @return Valor atual do registrador.
 */
uint8_t
MRF24::read_long(uint16_t reg)
{
   reg = (reg << 5) | 0x8000;
   cs.reset();
   spi.putc(reg >> 8);
   spi.putc(reg & 0xff);
   uint8_t res = spi.getc();
   cs.set();
   return res;
}

/**
 * Envia um pacote pelo rádio.
 * @param pckt Ponteiro para o pacote a enviar.
 * @param size Tamanho total do pacote em bytes.
 * @param header Quantidade de bytes do cabeçalho, se existente.
 */
void
MRF24::send(uint8_t *pckt, int size, int header)
{
   /*
    * Aguarda conclusão de transmissão anterior.
    */
   mutex.lock();
   for(int i=0; i<2000; i++) {
      uint8_t tmp = read_short(TXNCON);
      if((tmp & 0x01) == 0) goto ok;
      usleep(5);
   }
   throw runtime_error("Timeout de comunicação com o tranceiver.");

ok:
   /*
    * Transfere pacote ao transceiver.
    */
   cs.reset();
   spi.putc(0x80);
   spi.putc(0x10);
   spi.putc(header);
   spi.putc(size);
   for(int i=0; i<size; i++)
      spi.putc(*pckt++);
   cs.set();

   /*
    * Inicia transmissão.
    */
   write_short(TXNCON, 0b00000001);
   mutex.unlock();
}

/**
 * Verifica se existe pacote recebido no transceiver e o copia para a memória.
 * @param pckt Ponteiro para o buffer onde salvar o pacote recebido.
 * @param size Tamanho do buffer (máximo para o pacote).
 * @return Número de bytes recebidos (zero se não houver mensagem).
 */
int MRF24::recv(uint8_t *pckt, int size)
{
   /*
    * Verifica se houve recepção de mensagem.
    */
   mutex.lock();
   if((read_short(INTSTAT) & 0x08) == 0) {
      mutex.unlock();
      return 0;
   }

   /*
    * Interrompe a recepção para a transferência da mensagem.
    */
   write_short(BBREG1, 0b00000100);

   /*
    * Lê o pacote recebido, começando pelo tamanho.
    */
   cs.reset();
   spi.putc(0xe0);
   spi.putc(0);
   int tam = spi.getc() - 2;                   // desconta o CRC
   if(tam > size) {
      /*
       * Tamanho inválido.
       * Descarta a mensagem.
       */
      cs.set();
      write_short(BBREG1, 0);
      write_short(RXFLUSH, 0b00000001);
      mutex.unlock();
      return 0;
   }

   for(int i=0; i<tam; i++)
      *pckt++ = spi.getc();

   spi.getc();                                 // lê e descarta o CRC
   spi.getc();
   lqi = spi.getc();
   rssi = spi.getc();
   cs.set();

   /*
    * Descarta a mensagem no buffer do transceiver.
    */
   write_short(RXFLUSH, 0b00000001);
   write_short(BBREG1, 0);

   mutex.unlock();
   return tam;
}

/**
 * Provoca o reset do transceiver de rádio.
 */
void
MRF24::reset()
{
   mutex.lock();
   /*
    * Reset físico do componente.
    */
   rst.reset();
   usleep(5000);
   rst.set();
   usleep(10000);

   /*
    * Provoca reset por software.
    */
   write_short(SOFTRST, 0b00000111);                   // envia comando de reset completo
   for(int i=0; i<2000; i++) {
      uint8_t r = read_short(SOFTRST);
      if((r & 0x07) == 0) {
         mutex.unlock();
         return;
      }
      usleep(100);
   }

   throw runtime_error("Timeout de reset do transceiver.");
}

/**
 * Inicialização e configuracao do transceiver.
 * @param usa_lna Configura o transceiver para utilizar LNA/PA externo se igual a true.
 * @param turbo Configura o transceiver para operar no modo turbo se igual a true.
 */
void
MRF24::init(bool usa_lna, bool turbo)
{
   mutex.lock();
   cs.set();

   write_short(PACON2, 0x98);                          // habilita fifo
   write_short(TXSTBL, 0x95);                          // calibração recomendada

   write_long(RFCON1, 0x02);                           // inicializa VCOOPT
   write_long(RFCON2, 0x80);                           // ativa o PLL
   write_long(RFCON6, 0x90);                           // filtro de transmissão aitvo (valor recomendado)
   write_long(RFCON7, 0x80);                           // usar clock interno para modo sleep
   write_long(RFCON8, 0x10);                           // usa VCO especial (valor recomendado)
   write_long(SLPCON1, 0x21);                          // valor recomendado e divisor unitário (não utilizado).

   write_short(BBREG2, 0x80);                          // CCA modo 1, threshold = 0x0e (valor recomendado)
   write_short(CCAEDTH, 0x60);                         // threshold
   write_short(BBREG6, 0x40);                          // calcular RSSI por pacote

   if(usa_lna) {
      /*
       * Configura LNA/PA externo.
       */
      write_long(TESTMODE, 0x0f);                      // habilita PA externo
      write_short(TRISGPIO, 0b00001110);               // pinos de saída para controle
      write_short(GPIO_R, 0b00001000);                 // liga fonte externa
   }

   /*
    * Programa interrupções.
    */
   read_short(INTSTAT);                                // limpa interrupções pendentes
   write_short(INT_CON, 0b11110111);                   // habilita interrupção de recepção

   if(turbo) {
      /*
       * Programa modo de alta velocidade (625kbps).
       */
      write_short(BBREG0, 0x01);
      write_short(BBREG3, 0x38);
      write_short(BBREG4, 0x5c);
   }

   /*
    * Reinicia máquina de estados RF.
    */
   write_long(RFCON0, 0x03);
   write_short(RFCTL, 0x04);
   write_short(RFCTL, 0);
   usleep(200);

   /*
    * Configura recepção de pacotes.
    */
   write_short(RXMCR, 0b00000001);                     // ACK automático, recebe pacotes com CRC correto (modo promíscuo)
   write_short(RXFLUSH, 0b00000001);                   // limpa o buffer de recepção
   mutex.unlock();
}

/**
 * Define o canal de rádio do transceiver.
 * @param ch Canal desejado (11-26).
 */
void
MRF24::set_channel(uint8_t ch)
{
   if((ch < 11) || (ch > 26)) throw runtime_error("Canal Inválido.");
   mutex.lock();
   write_long(RFCON0, ((ch-11) << 4) | 0x03);          // seleciona canal e otimização
   write_short(RFCTL, 0x04);
   write_short(RFCTL, 0);
   usleep(200);
   mutex.unlock();
}

/**
 * Define a potência de transmissão.
 * @param pw Potência entre 0 (máxima) e 31 (mínima).
 */
void
MRF24::set_power(uint8_t pw)
{
   mutex.lock();
   write_long(RFCON3, pw << 3);                        // programa a potência do transmissor
   mutex.unlock();
}

void
MRF24::set_message_callback(function<void(void)> fn)
{
   if(aux == nullptr) {
      aux = new ThreadMessage(fn, &irq);
   } else aux->callback = fn;
}

/**
 * Construtor.
 */
MRF24::MRF24(string device)
   : spi(device, 20000000),
     rst(RST_PIN, true),
     cs(CS_PIN, true, 5),
     irq(IRQ_PIN)

{
   irq.edge("falling");
   rst.set();
   cs.set();
}
