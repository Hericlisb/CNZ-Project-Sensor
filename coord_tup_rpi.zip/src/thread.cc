
#include <thread.h>
#include <signal.h>
#include <stdexcept>
using namespace std;

#include <stdio.h>
#include <unistd.h>

static void *__thread_entry_function(void *obj)
{
   ((Thread*)obj)->run();
   if(((Thread*)obj)->free_on_terminate)
      delete (Thread*)obj;
   return 0;
}

Thread::Thread(bool free_on_terminate)
{
   int res = pthread_create(&this->handler, NULL, __thread_entry_function, this);
   if(res) throw runtime_error("Cannot create thread.");
   this->free_on_terminate = free_on_terminate;
}

Thread::~Thread()
{
   pthread_join(handler, NULL);
}

void Thread::signal(int n)
{
   pthread_kill(handler, n);
}

void Thread::join(Thread& t)
{
   pthread_join(t.handler, NULL);
}

void Thread::yield()
{
   pthread_yield();
}

bool Thread::sleep_us(int n)
{
   if(usleep(n) < 0) return false;
   return true;
}

bool Thread::sleep_ms(int n)
{
   if(usleep(1000 * n) < 0) return false;
   return true;
}

bool Thread::sleep(int n)
{
   if(usleep(1000000 * n) < 0) return false;
   return true;
}

Mutex::Mutex() {
   this->mtx = PTHREAD_MUTEX_INITIALIZER;
}

Mutex::~Mutex() {
}

void Mutex::lock() {
   pthread_mutex_lock(&this->mtx);
}

void Mutex::unlock() {
   pthread_mutex_unlock(&this->mtx);
}

AtomicInt::AtomicInt(int n)
{
   val = n;
}

void AtomicInt::set(int v)
{
   mutex.lock();
   val = v;
   mutex.unlock();
}

int AtomicInt::get() {
   mutex.lock();
   int r = val;
   mutex.unlock();
   return r;
}

int AtomicInt::add(int v) {
   mutex.lock();
   int r = val = val + v;
   mutex.unlock();
   return r;
}

int AtomicInt::sub(int v) {
   mutex.lock();
   int r = val = val - v;
   mutex.unlock();
   return r;
}
