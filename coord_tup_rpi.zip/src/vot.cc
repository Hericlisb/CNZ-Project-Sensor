
#include <stdint.h>
#include <time.h>
#include "thread.h"
#include "mrf24j40.h"

#include <string.h>
#include <stdexcept>

#define __PACKED     __attribute__((packed))

#define TIPO_ESTADO              0x01
#define TIPO_POKE                0x02
#define TIPO_NETUP               0x10

#define EST_ESPERA               0
#define EST_NENHUM               1
#define EST_ABS                  2
#define EST_SIM                  3
#define EST_NAO                  4
#define EST_DESLIGADO            5

/**
 * Cabeçalho das mensagens do protocolo.
 */
typedef struct __PACKED {
   uint8_t fcr0;                                                ///< Frame control field LSB, IEEE 802.15.4.
   uint8_t fcr1;                                                ///< Frame control field MSB, IEEE 802.15.4.
   uint8_t seq;                                                 ///< Número de sequência, IEEE 802.15.4.
   uint8_t dest;
   uint8_t orig;
   uint8_t net_id;                                              ///< Identificador da rede.
   uint8_t ttl;                                                 ///< Time-to-live, decrementado a cada retransmissão.
   uint8_t tipo;                                                ///< Tipo da mensagem = 0x10.
   uint8_t dist;
   uint8_t lqi;                                                 ///< Indicação de qualidade da rota.
   uint8_t vid;
   uint8_t cmd;
   uint8_t map[32];
} frame_beacon_t;

/**
 * Mensagem de dados.
 */
typedef struct __PACKED {
   uint8_t fcr0;                                                ///< Frame control field LSB, IEEE 802.15.4.
   uint8_t fcr1;                                                ///< Frame control field MSB, IEEE 802.15.4.
   uint8_t seq;                                                 ///< Número de sequência, IEEE 802.15.4.
   uint8_t dest;
   uint8_t orig;
   uint8_t net_id;                                              ///< Identificador da rede.
   uint8_t ttl;                                                 ///< Time-to-live, decrementado a cada retransmissão.
   uint8_t tipo;                                                ///< Tipo da mensagem = 0x01.
   uint8_t status;
   uint8_t bat_sig;
} frame_status_t;

/**
 * Mensagem de teste.
 */
typedef struct __PACKED {
   uint8_t fcr0;                                                ///< Frame control field LSB, IEEE 802.15.4.
   uint8_t fcr1;                                                ///< Frame control field MSB, IEEE 802.15.4.
   uint8_t seq;                                                 ///< Número de sequência, IEEE 802.15.4.
   uint8_t dest;
   uint8_t orig;
   uint8_t net_id;                                              ///< Identificador da rede.
   uint8_t ttl;                                                 ///< Time-to-live, decrementado a cada retransmissão.
   uint8_t tipo;                                                ///< Tipo da mensagem = 0x02.
} frame_poke_t;

/**
 * Estado de um terminal de votação.
 */
typedef struct {
   uint8_t estado;                                             ///< ESPERA, NENHUM, ABS, SIM, NÃO, DESLIGADO
   uint8_t bateria;                                            ///< 0-15 estado de carga da bateria
   uint8_t sinal;                                              ///< 0-15 qualidade do link de rádio
   bool comunicando;                                           ///< false indica timeout de comunicação.
   bool habilitado;                                            ///< Comando de habilitação/desabilitação remota.
   bool erro;                                                  ///< Comando de sinalização remota de erro.
   time_t ultimo;                                              ///< Estampa de tempo para verificação de timeout.
} terminal_t;


class ControleVot: public Thread {
public:
   ControleVot(MRF24 *radio);
   virtual ~ControleVot();
   terminal_t terminais[256];

   void inicia_votacao();
   void encerra_votacao();
   void habilita_terminal(int n, bool hab=true);
   void sinalizacao_erro(int n, bool hab=true);
   void atualiza_terminais();
   void atualiza_erro();
   void processa_mensagem();
   virtual void run();

private:
   void envia_comando_inicio();
   void envia_comando_fim();
   void envia_comando_ack();
   void envia_comando_habilita();
   void envia_comando_erro();
   uint8_t confirma[32];
   MRF24 *radio;
   uint8_t nro_votacao;
   uint8_t sequencia;
   bool votacao_em_andamento;
   AtomicInt comando;
   Mutex mutex;
};

static ControleVot *Singleton = nullptr;

void
radio_callback(void) {
   if(Singleton == nullptr) return;
   Singleton->processa_mensagem();
}

/**
 * Construtor.
 */
ControleVot::ControleVot(MRF24 *radio)
{
   Singleton = this;
   this->radio = radio;
   radio->set_message_callback(radio_callback);
   nro_votacao = 1;
   sequencia = 0;
   votacao_em_andamento = false;
   comando.set(0);
   memset(confirma, 0, sizeof(confirma));
}

ControleVot::~ControleVot()
{
   Singleton = nullptr;
}

/**
 * Monta e envia uma mensagem de início de votação à rede.
 */
void
ControleVot::envia_comando_inicio()
{
   frame_beacon_t msg;
   msg.fcr0 = 0b00000001;        // mensagem de dados
   msg.fcr1 = 0x00;              // sem campos de endereçamento
   msg.seq = sequencia++;        // numero de sequência atual
   msg.dest = 0xff;              // toda a rede
   msg.orig = 0;                 // coordenador
   msg.net_id = 0x3c;            // identificador da rede
   msg.ttl = 10;
   msg.tipo = TIPO_NETUP;

   msg.dist = 0;
   msg.lqi = 0xff;
   msg.cmd = 0;
   msg.vid = nro_votacao;

   radio->send((uint8_t*)&msg, sizeof(msg)-32);
}

/**
 * Monta e envia uma mensagem de encerramento de votação à rede.
 */
void
ControleVot::envia_comando_fim()
{
   frame_beacon_t msg;
   msg.fcr0 = 0b00000001;        // mensagem de dados
   msg.fcr1 = 0x00;              // sem campos de endereçamento
   msg.seq = sequencia++;        // numero de sequência atual
   msg.dest = 0xff;              // toda a rede
   msg.orig = 0;                 // coordenador
   msg.net_id = 0x3c;            // identificador da rede
   msg.ttl = 10;
   msg.tipo = TIPO_NETUP;

   msg.dist = 0;
   msg.lqi = 0xff;
   msg.cmd = 1;
   msg.vid = nro_votacao;

   radio->send((uint8_t*)&msg, sizeof(msg)-32);
}

/**
 * Monta e envia uma mensagem de acompanhamento de votação,
 * incluindo campos de acknowledge para os terminais.
 */
void
ControleVot::envia_comando_ack()
{
   frame_beacon_t msg;
   msg.fcr0 = 0b00000001;        // mensagem de dados
   msg.fcr1 = 0x00;              // sem campos de endereçamento
   msg.seq = sequencia++;        // numero de sequência atual
   msg.dest = 0xff;              // toda a rede
   msg.orig = 0;                 // coordenador
   msg.net_id = 0x3c;            // identificador da rede
   msg.ttl = 10;
   msg.tipo = TIPO_NETUP;

   msg.dist = 0;
   msg.lqi = 0xff;
   msg.cmd = 4;
   msg.vid = nro_votacao;
   memcpy(msg.map, this->confirma, 32);

   radio->send((uint8_t*)&msg, sizeof(msg));
}

/**
 * Monta e envia uma mensagem de habilitação/desabilitação de terminais.
 */
void
ControleVot::envia_comando_habilita()
{
   frame_beacon_t msg;
   msg.fcr0 = 0b00000001;        // mensagem de dados
   msg.fcr1 = 0x00;              // sem campos de endereçamento
   msg.seq = sequencia++;        // numero de sequência atual
   msg.dest = 0xff;              // toda a rede
   msg.orig = 0;                 // coordenador
   msg.net_id = 0x3c;            // identificador da rede
   msg.ttl = 10;
   msg.tipo = TIPO_NETUP;

   msg.dist = 0;
   msg.lqi = 0xff;
   msg.cmd = 2;
   msg.vid = nro_votacao;

   for(int i=0; i<256; i++) {
      uint8_t j = i >> 3;
      uint8_t m = 1 << (i & 0x07);
      if(terminais[i].habilitado) msg.map[j] |= m;
      else msg.map[j] &= (~m);
   }

   radio->send((uint8_t*)&msg, sizeof(msg));
}

/**
 * Monta e envia uma mensagem de sinalização de erro.
 */
void
ControleVot::envia_comando_erro()
{
   frame_beacon_t msg;
   msg.fcr0 = 0b00000001;        // mensagem de dados
   msg.fcr1 = 0x00;              // sem campos de endereçamento
   msg.seq = sequencia++;        // numero de sequência atual
   msg.dest = 0xff;              // toda a rede
   msg.orig = 0;                 // coordenador
   msg.net_id = 0x3c;            // identificador da rede
   msg.ttl = 10;
   msg.tipo = TIPO_NETUP;

   msg.dist = 0;
   msg.lqi = 0xff;
   msg.cmd = 3;
   msg.vid = nro_votacao;

   for(int i=0; i<256; i++) {
      uint8_t j = i >> 3;
      uint8_t m = 1 << (i & 0x07);
      if(terminais[i].erro) msg.map[j] |= m;
      else msg.map[j] &= (~m);
   }

   radio->send((uint8_t*)&msg, sizeof(msg));
}

/**
 * Trata uma mensagem recebida pelo transceiver,
 * atualizando o estado dos terminais envolvidos.
 */
void
ControleVot::processa_mensagem()
{
   uint8_t msg[128];
   int size = radio->recv(msg, sizeof(msg));
   if(size < sizeof(frame_status_t)) return;

   frame_status_t *frame = (frame_status_t*)msg;
   uint8_t id = frame->orig;
   if(id == 0) return;

   switch(frame->tipo) {
      /*
       * Mensagem de estado de terminal.
       */
      case TIPO_ESTADO:
         /*
          * Atualiza elemento e sinaliza comunicação ok.
          */
         terminais[id].estado = frame->status;
         terminais[id].bateria = frame->bat_sig >> 4;
         terminais[id].sinal = frame->bat_sig & 0x0f;
         terminais[id].comunicando = true;
         terminais[id].ultimo = time(NULL);

         if(frame->status >= EST_ABS) {
            /*
             * Marca voto recebido.
             */
            int i = id >> 3;
            int m = confirma[i];
            confirma[i] = m | (1 << (id & 0x07));
         }
         break;

      /*
       * Mensagem de keep-alive.
       */
      case TIPO_POKE:
         /*
          * Sinaliza comunicação ok.
          */
         terminais[id].comunicando = true;
         terminais[id].ultimo = time(NULL);
         break;
   }
}

#define TEMPO_SCAN         3000000              // 3s

/**
 * Ponto de entrada do thread de comunicação.
 * Executa comandos recebidos e faz a varredura da rede.
 */
void
ControleVot::run()
{
   for(;;) {
      int cmd = comando.get();
      switch(cmd) {
         /*
          * Nenhum comando recebido.
          */
         case 0:
            /*
             * Aguarda tempo de scan ou chegada de comando.
             * sleep_us será interrompido por um comando.
             */
            if(!sleep_us(TEMPO_SCAN)) break;
            if(votacao_em_andamento) envia_comando_ack();
            break;

         /*
          * Comando para iniciar nova votação.
          */
         case 1:
            /*
             * Inicia votação, zera bits de confirmação.
             */
            nro_votacao++;
            memset(this->confirma, 0, 32);
            envia_comando_inicio();
            break;

         /*
          * Comando para encerrar votação.
          */
         case 2:
            envia_comando_fim();
            break;

         /*
          * Comando para habilitar/desabilitar terminais.
          */
         case 3:
            envia_comando_habilita();
            break;

         /*
          * Comando para sinalização de erro nos terminais.
          */
         case 4:
            envia_comando_erro();
            break;
      }
   }
}

void
ControleVot::habilita_terminal(int n, bool hab)
{
   if((n < 1) || (n > 255)) throw runtime_error("Terminal inválido.");
   terminais[n].habilitado = hab;
}

void
ControleVot::sinalizacao_erro(int n, bool hab)
{
   if((n < 1) || (n > 255)) throw runtime_error("Terminal inválido.");
   terminais[n].erro = hab;
}

/**
 * Solicita início de votação (comando 1).
 * Envia um sinal ao thread de execução.
 */
void
ControleVot::inicia_votacao()
{
   if(votacao_em_andamento) return;
   votacao_em_andamento = true;
   comando.set(1);
   this->signal(35);
}

/**
 * Solicita encerramento de votação (comando 2).
 * Envia um sinal ao thread de execução.
 */
void
ControleVot::encerra_votacao()
{
   if(!votacao_em_andamento) return;
   votacao_em_andamento = false;
   comando.set(2);
   this->signal(35);
}

/**
 * Solicita envio de mensagem de habilitação de terminais.
 */
void
ControleVot::atualiza_terminais()
{
   comando.set(3);
   this->signal(35);
}

/**
 * Solicita envio de mensagem de sinalização de erro.
 */
void
ControleVot::atualiza_erro()
{
   comando.set(4);
   this->signal(35);
}
