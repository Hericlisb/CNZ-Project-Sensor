
#include "scan.h"
#include <string.h>
#include <time.h>
#include "config.h"
#include <syslog.h>

#define __PACKED __attribute__((packed))

#define CMD_BEACON            0x00
#define CMD_DATA              0x01

/**
 * Mensagens do protocolo.
 */
typedef struct __PACKED {
   uint8_t fcr0;                                ///< Frame control field LSB, IEEE 802.15.4.
   uint8_t fcr1;                                ///< Frame control field MSB, IEEE 802.15.4.
   uint8_t seq;                                 ///< Número de sequência, IEEE 802.15.4.
   uint8_t pan;                                 ///< Identificador da rede.
   uint8_t source;                              ///< Endereço de origem da mensagem.
   uint8_t destination;                         ///< Endereço de destino da mensagem.
   uint8_t ttl;                                 ///< Time-to-live, decrementado a cada retransmissão.
   uint8_t command;                             ///< Tipo da mensagem.
   uint8_t lqi;                                 ///< Indicação de qualidade da rota.
} frame_beacon_t;

/**
 * Mensagem de dados.
 */
typedef struct __PACKED {
   uint8_t fcr0;                                ///< Frame control field LSB, IEEE 802.15.4.
   uint8_t fcr1;                                ///< Frame control field MSB, IEEE 802.15.4.
   uint8_t seq;                                 ///< Número de sequência, IEEE 802.15.4.
   uint8_t pan;                                 ///< Identificador da rede.
   uint8_t source;                              ///< Endereço de origem da mensagem.
   uint8_t destination;                         ///< Endereço de destino da mensagem.
   uint8_t ttl;                                 ///< Time-to-live, decrementado a cada retransmissão.
   uint8_t command;                             ///< Tipo da mensagem.
   uint8_t next_hop;                            ///< Informação de roteamento local: próximo nó.
   uint8_t lqi;                                 ///< Qualidade da rota atual.
   int16_t am2301_temperatura;                  ///< Estado dos sensores.
   uint16_t am2301_umidade;
   int16_t bm180_temperatura;
   uint32_t bm180_pressao;
} frame_data_t;


/**
 * Construtor.
 */
Scanner::Scanner(shared_ptr<MRF24> radio, shared_ptr<GPIO> led)
{
   this->radio = radio;
   this->led = led;
   radio_reset();
   sequencia = 0;
   timeout = 0;
}

/**
 * Ponto de entrada do thread de execução do coordenador.
 * Envia mensagem de beacon periodicamente, verifica e trata timeout do transceiver.
 */
void
Scanner::run()
{
   while(!terminated) {
      /*
       * Aguarda temporização para envio de mensagem.
       */
      usleep(TEMPO_BEACON);

      /*
       * Verifica timeout de comunicação.
       */
      if(++timeout > TIMEOUT_RADIO) {
         timeout = 0;
         syslog(LOG_WARNING, "Radio transceiver timeout, reseting.");
         radio_reset();
      }

      /*
       * Verifica timeout dos sensores.
       */
      testa_timeouts();

      /*
       * Envia mensagem, piscando o led.
       */
      led->set();
      envia_beacon();
      usleep(20000);
      led->reset();
   }
}

/**
 * Monta e envia uma mensagem de manutenção de rede.
 */
void
Scanner::envia_beacon()
{
   frame_beacon_t msg;
   msg.fcr0 = 0b00000001;        // mensagem de dados
   msg.fcr1 = 0x00;              // sem campos de endereçamento
   msg.seq = sequencia++;        // numero de sequência atual
   msg.destination = 0xff;       // toda a rede
   msg.source = 0;               // coordenador
   msg.pan = NETWORK_ID;         // identificador da rede
   msg.ttl = 10;
   msg.command = CMD_BEACON;
   msg.lqi = 0xff;

   radio->send((uint8_t*)&msg, sizeof(msg));
}

/**
 * Trata uma mensagem recebida do transceiver.
 */
void
Scanner::processa_mensagem()
{
   uint8_t _msg[128];
   int tmp;

   /*
    * Transfere mensagem do rádio.
    */
   int size = radio->recv(_msg, sizeof(_msg));
   if(size < sizeof(frame_data_t)) return;
   frame_data_t *msg = (frame_data_t*)_msg;

   /*
    * Verifica mensagem válida.
    */
   if(msg->pan != NETWORK_ID) return;
   if(msg->command != CMD_DATA) return;
   if((msg->destination != 0xff) && (msg->destination != 0)) return;

   int id = msg->source;
   if(id >= MAX_ID) return;

   /*
    * Atualiza informações locais.
    */
   timeout = 0;
   mutex.lock();

   sensor_data_t *ptr = &dados[id];
   ptr->id = id;
   ptr->stamp = time(NULL);
   ptr->next = msg->next_hop;
   ptr->lqi = msg->lqi;

   tmp = msg->am2301_temperatura;
   if(tmp == 0xffff) ptr->temp.valido = false;
   else {
      ptr->temp.valor = (float)tmp / 10.0;
      ptr->temp.valido = true;
   }

   tmp = msg->am2301_umidade;
   if(tmp == 0xffff) ptr->umidade.valido = false;
   else {
      ptr->umidade.valor = (float)tmp / 10.0;
      ptr->umidade.valido = true;
   }

   tmp = msg->bm180_temperatura;
   if(tmp == 0xffff) ptr->temp_alt.valido = false;
   else {
      ptr->temp_alt.valor = (float)tmp / 10.0;
      ptr->temp_alt.valido = true;
   }

   tmp = msg->bm180_pressao;
   if(tmp == 0xffffff) ptr->pressao.valido = false;
   else {
      ptr->pressao.valor = (float)tmp / 100.0;
      ptr->pressao.valido = true;
   }
   mutex.unlock();

#ifdef DEBUG
   syslog(LOG_DEBUG, "** Recebido id = %d\n", id);
#endif
}

/**
 * Provoca reset do transceiver de rádio no caso de timeout.
 * Reconfigura o transceiver para continuar operação.
 */
void
Scanner::radio_reset()
{
   radio->reset();
   radio->init(true);
   radio->set_channel(CHANNEL_NR);
   radio->set_power(0);
   radio->set_message_callback([this]() { this->processa_mensagem(); });
}

/**
 * Lê as informações recebidas do sensor identificado.
 * @param id Endereço do sensor de interesse.
 * @param data Ponteiro para uma estrutura sensor_data_t a ser preenchida.
 * @return true se os dados são válidos (sensor comunicante).
 */
bool
Scanner::get_data(int id, sensor_data_t& data)
{
   if(id >= MAX_ID) return false;
   mutex.lock();
   if(dados.find(id) == dados.end()) {       // endereço não existente.
      mutex.unlock();
      return false;
   }
   memcpy(&data, &dados[id], sizeof(sensor_data_t));
   mutex.unlock();
   return true;
}

/**
 * Varre a lista de sensores e verifica ausência de comunicação.
 * Remove os sensores não comunicantes da lista.
 */
void
Scanner::testa_timeouts()
{
   time_t now = time(NULL);

   mutex.lock();
   for(auto i=dados.begin(); i!=dados.end();) {
      if(now - (*i).second.stamp > TIMEOUT_SENSOR) {
         syslog(LOG_WARNING, "Sensor %d timeout.", (*i).second.id);
         dados.erase(i++);
      } else ++i;
   }
   mutex.unlock();
}
