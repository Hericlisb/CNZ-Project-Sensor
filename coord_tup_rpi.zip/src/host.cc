
#include "host.h"
#include "stdarg.h"
#include <string.h>
#include <signal.h>

#include "config.h"
#include <syslog.h>

/**
 * Construtor.
 * Cria objetos socket e timer e associa com o objeto Scanner externo.
 */
Servidor::Servidor(shared_ptr<Scanner> s, int port)
   : sckt(port),
     timer(TEMPO_SCAN, [this]() { this->send_data(); })
{
   scanner = s;
   output = NULL;
}

/**
 * Destrutor.
 * Fecha todos os sockets abertos.
 */
Servidor::~Servidor()
{
   for(auto &i : clientes) {
      i->close();
   }
   sckt.close();
}

/**
 * Ponto de entrada do thread de execução do serviço.
 * Aguarda conexões e coloca os clientes na lista.
 */
void
Servidor::run(void)
{
   while(!terminated) {
      auto c = sckt.listen();
      if(c) {
         syslog(LOG_INFO, "Client connected from %s.", c->get_address());
         clientes.push_back(move(c));
      }
   }
}

/**
 * Envia os dados de um sensor a todos os clientes ativos
 * no formato "id;pressão;umidade;temperatura\r\n".
 * Remove da lista eventuais clientes desconectados.
 * Atualiza também o arquivo de saída, se estiver aberto.
 * @param id Identificador do sensor.
 * @param dados Estado atual do sensor.
 */
void
Servidor::send_all(int id, sensor_data_t& dados)
{
   /*
    * Formata o texto de saída.
    */
   char buf[256];
   char *ptr = buf;
   ptr += sprintf(ptr, "%02d;", id);

   if(dados.pressao.valido) {
      ptr += sprintf(ptr, "%.2f;", dados.pressao.valor);
   } else {
      *ptr++ = ';';
   }

   if(dados.umidade.valido) {
      ptr += sprintf(ptr, "%.1f;", dados.umidade.valor);
   } else {
      *ptr++ = ';';
   }

   if(dados.temp.valido) {
      ptr += sprintf(ptr, "%.1f", dados.temp.valor);
   } else if(dados.temp_alt.valido) {
      ptr += sprintf(ptr, "%.1f", dados.temp_alt.valor);
   }

   *ptr++ = '\r';
   *ptr++ = '\n';
   *ptr++ = 0;

#ifdef DEBUG
   syslog(LOG_DEBUG, "%s", buf);
#endif

   /*
    * Varre a lista de clientes para enviar o texto.
    */
   for(auto i=clientes.begin(); i!=clientes.end();) {
      int n = (*i)->write((void*)buf, strlen(buf));
      if(n <= 0) {
         /*
          * Cliente desconectado: remove da lista.
          */
         syslog(LOG_INFO, "Client %s disconnected.", (*i)->get_address());
         i = clientes.erase(i);
      } else i++;
   }

   /*
    * Salva no arquivo de saída, se aberto.
    * Inclui os campos de estado da comunicação.
    */
   if(output != NULL) {
      sprintf(ptr-3, ";%d;%d\n", dados.next, dados.lqi);
      fprintf(output, buf);
   }
}

/**
 * Envia os dados dos sensores ativos a todos os clientes.
 * Salva informações em arquivo CSV.
 */
void
Servidor::send_data()
{
   int n;
   sensor_data_t dados;

   /*
    * Abre arquivo para armazenar dados de sensores.
    */
   output = fopen(TMP_FILE, "w");

   /*
    * Varre todos os sensores.
    */
   for(n=0; n<MAX_ID; n++) {
      if(scanner->get_data(n, dados)) {
         send_all(n, dados);
      }
   }

   /*
    * Conclui o arquivo de saída.
    */
   if(output != NULL)
      fclose(output);
   unlink(OUT_FILE);
   rename(TMP_FILE, OUT_FILE);
   output = NULL;
}

/**
 * Objeto auxiliar de temporização. Construtor.
 */
MyTimer::MyTimer(int interval, function<void(void)>fn)
{
   this->tempo = interval;
   this->callback = fn;
}

/**
 * Ponto de entrada do thread de execução.
 * Aguarda tempo configurado e aciona a rotina callback especificada.
 */
void
MyTimer::run()
{
   /*
    * Mascara o sinal SIGPIPE para não interromper o programa
    * quando algum cliente desconectar.
    */
   sigset_t sigpipe_mask;
   sigemptyset(&sigpipe_mask);
   sigaddset(&sigpipe_mask, SIGPIPE);
   sigset_t saved_mask;
   if (pthread_sigmask(SIG_BLOCK, &sigpipe_mask, &saved_mask) == -1) throw runtime_error("Sigmask");

   while(!terminated) {
      this->sleep(TEMPO_SCAN);
      callback();
   }
}
