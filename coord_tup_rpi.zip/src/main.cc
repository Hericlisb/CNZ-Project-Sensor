
#include "mrf24j40.h"
#include "scan.h"
#include "host.h"
#include "log.h"
#include "config.h"

#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <syslog.h>
#include <locale.h>

#include <libconfig.h++>
using namespace libconfig;

/*
 * Parâmetros de configuração.
 */
int port_to_listen = PORT_TO_LISTEN;
int tempo_log = TEMPO_LOG;
string log_dir = LOG_DIR;

/**
 * Executa a aplicação.
 */
void
_run()
{
   try {
      shared_ptr<GPIO> led(new GPIO(LED_GPIO, true));
      shared_ptr<MRF24> radio(new MRF24(MRF_DEV));
      shared_ptr<Scanner> scanner(new Scanner(radio, led));
      Servidor *host = new Servidor(scanner, port_to_listen);
      Datalog data(scanner, log_dir, tempo_log);

      /*
       * Inicialização completa. Em execução.
       */
      syslog(LOG_INFO, "Service started.");
      for(;;) {
         sleep(30);
      }
   } catch(runtime_error &e) {
      /*
       * Falha na interface com o dispositivo.
       */
      syslog(LOG_CRIT, "Hardware error: %s.", e.what());
      exit(EXIT_FAILURE);
   }
}

/**
 * Tenta carregar os parâmetros de configuração.
 */
void
_configura()
{
   /*
    * Carrega arquivo de configuração (utiliza libconfig++.so)
    */
   Config cfg;
   try {
      cfg.readFile("/etc/coord.conf");
   } catch(FileIOException &e) {
      /*
       * Arquivo não existente, assume valores default.
       */
      return;
   } catch (ParseException &e) {
      syslog(LOG_ERR, "Error in configuration file '%s':%d", e.getFile(), e.getLine());
      return;
   }

   /*
    * Lê os valores configurados.
    * Assume valores default se não encontrados.
    */
   try {
      tempo_log = cfg.lookup("datalogger.interval");
   } catch(SettingNotFoundException &e) { }

   try {
      string x = cfg.lookup("datalogger.path");
      log_dir = x;
   } catch(SettingNotFoundException &e) { }

   try {
      port_to_listen = cfg.lookup("network.port");
   } catch(SettingNotFoundException &e) { }
}

int
main(int argc, char **argv)
{
   /*
    * Executa processo como daemon.
    * Será executado como root a partir do init.d
    */
   umask(022);

   /*
    * Diretório de trabalho.
    */
   if ((chdir("/")) < 0) {
      syslog(LOG_CRIT, "Filesystem failure.");
      exit(EXIT_FAILURE);
   }

   /*
    * Redefine o local para gerar números com decimal separado com vírgula.
    */
   setlocale(LC_NUMERIC, "");

   /*
    * Fecha os arquivos standard (não existe mais console).
    */
   close(STDIN_FILENO);
   close(STDOUT_FILENO);
   close(STDERR_FILENO);

   /*
    * Executa a aplicação.
    */
   _configura();
   _run();
}
