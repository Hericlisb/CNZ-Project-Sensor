
#include "gpio.h"
#include <unistd.h>
#include <fcntl.h>
#include <poll.h>
#include <stdexcept>
#include <string.h>
#include <sys/ioctl.h>
using namespace std;

/**
 * Construtor.
 * Define pino e direção.
 * @param port Índice do pino desejado.
 * @param output true se for pino de saída.
 * @param delay Tempo em us após transição do sinal (0 = desabilita).
 */
GPIO::GPIO(int port, bool output, int delay)
{
   char str[80];

   this->port = port;
   this->output = output;
   this->delay = delay;

   for(;;) {
      sprintf(str, "/sys/class/gpio/gpio%d/direction", port);
      if(access(str, W_OK) != -1) break;

      fd = open("/sys/class/gpio/export", O_WRONLY | O_TRUNC);
      if(fd < 0) throw runtime_error("Cannot assign GPIO");

      int t = sprintf(str, "%d\n", port);
      write(fd, str, t);
      close(fd);

      usleep(10000);
   }

   fd = open(str, O_WRONLY | O_TRUNC);
   if(fd < 0) throw runtime_error("Cannot define GPIO direction");

   if(output) write(fd, "out\n", 4);
   else write(fd, "in\n", 3);
   close(fd);

   sprintf(str, "/sys/class/gpio/gpio%d/value", port);
   fd = open(str, O_RDWR);
   if(fd < 0) throw runtime_error("Cannot assign GPIO");
   current = read();
}

GPIO::~GPIO()
{
   close(fd);

   char pin[5];
   fd = open("/sys/class/gpio/export", O_WRONLY | O_TRUNC);
   int i = sprintf(pin, "%d\n", port);
   write(fd, pin, i);
   close(fd);
}

bool
GPIO::read()
{
   char value;
   int i = ::read(fd, &value, 1);
   if(i != 1) throw runtime_error("GPIO reading failure");
   lseek(fd, 0, SEEK_SET);

   if(value == '0') current = false;
   else current = true;
   return current;
}

void
GPIO::set()
{
   current = true;
   write(fd, "1\n", 2);
   lseek(fd, 0, SEEK_SET);
   if(delay) usleep(delay);
}

void
GPIO::reset()
{
   current = false;
   write(fd, "0\n", 2);
   lseek(fd, 0, SEEK_SET);
   if(delay) usleep(delay);
}

void
GPIO::toggle()
{
   current = !current;
   if(current) set();
   else reset();
}

void
GPIO::edge(string v)
{
   char tmp[40];
   sprintf(tmp, "/sys/class/gpio/gpio%d/edge", port);
   int f = open(tmp, O_WRONLY | O_TRUNC);
   if(f < 0) throw runtime_error("GPIO set edge failure.");
   write(f, v.c_str(), v.length());
   close(f);
}

bool
GPIO::wait(int timeout)
{
   struct pollfd p;
   char c;

   memset(&p, 0, sizeof(p));
   p.fd = fd;
   p.events =  POLLPRI;

   int res = poll(&p, 1, timeout);
   if(res < 0) throw runtime_error("GPIO interrupt error");

   read();

   if(p.revents & POLLPRI) return true;
   return false;
}

void
GPIO::operator=(bool v)
{
   if(v) set(); else reset();
}

void
GPIO::operator=(int v)
{
   if(v) set(); else reset();
}

GPIO::operator bool()
{
   return read();
}

GPIO::operator int()
{
   return read();
}
