
#include "spi.h"
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <linux/spi/spidev.h>
#include <stdexcept>
using namespace std;

SPI::SPI(string dev, uint32_t clk)
{
   this->dev = dev;
   this->clk = clk;

   fd = open(this->dev.c_str(), O_RDWR);
   if(fd < 0) throw runtime_error("SPI device general failure");

   int mode = SPI_MODE_0;
   int res = ioctl(fd, SPI_IOC_WR_MODE, &mode);
   if(res == -1) throw runtime_error("SPI mode configuration failure");

   int bits = 8;
   res = ioctl(fd, SPI_IOC_WR_BITS_PER_WORD, &bits);
   if(res == -1) throw runtime_error("SPI word size configuration failure");

   res = ioctl(fd, SPI_IOC_RD_MAX_SPEED_HZ, &clk);
   if(res == -1) throw runtime_error("SPI clock frequency configuration failure");
}

SPI::~SPI()
{
   close(fd);
}

bool SPI::transfer(uint8_t *tx, uint8_t *rx, uint8_t size)
{
   struct spi_ioc_transfer tr;
   tr.tx_buf = (unsigned long)tx;
   tr.rx_buf = (unsigned long)rx;
   tr.len = size;
   tr.delay_usecs = 2;
   tr.speed_hz = clk;
   tr.bits_per_word = 8;

   int res = ioctl(fd, SPI_IOC_MESSAGE(1), &tr);
   if(res < 1) return false;
   return true;
}

void SPI::write(uint8_t *tx, int size)
{
   ::write(fd, tx, size);
}

int SPI::read(uint8_t *rx, int size)
{
   ::read(fd, rx, size);
}

void SPI::putc(uint8_t c)
{
   ::write(fd, &c, 1);
}

int SPI::getc()
{
   uint8_t r;
   ::read(fd, &r, 1);
   return r;
}
