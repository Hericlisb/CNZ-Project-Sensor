
#include "log.h"
#include "config.h"

/**
 * Construtor.
 * @param s Objeto Scanner de onde obter os dados.
 * @param logdir Diretório para salvamento dos arquivos.
 * @param tempo Tempo (em segundos) para amostragem.
 */
Datalog::Datalog(shared_ptr<Scanner> s, string logdir, int tempo)
{
   scanner = s;
   this->tempo = tempo;
   this->path = logdir;
   if(path.back() == '/') path.pop_back();
}

/**
 * Ponto de entrada do thread de execução.
 * Aguarda o tempo de amostragem e dispara a aquisição de dados.
 */
void
Datalog::run()
{
   while(!terminated) {
      Thread::sleep(tempo);
      log_now();
   }
}

/**
 * Aquisição de dados.
 * Varre todos os ID possíveis, enviando dados válidos para o arquivo.
 */
void
Datalog::log_now()
{
   int i;
   sensor_data_t dados;
   for(i=1; i<MAX_ID; i++) {
      if(scanner->get_data(i, dados))
         log_item(dados);
   }
}

/**
 * Formata e grava dados no arquivo.
 * O nome do arquivo é montado no formado [id].CSV
 * Verifica a estampa de tempo do dado recebido para evitar duplicações.
 * Salva dados no formato "id;estampa;pressão;umidade;temperatura\n"
 */
void
Datalog::log_item(sensor_data_t& data)
{
   int id = data.id;

   /*
    * Verifica dupla aquisição.
    */
   if(stamps[id] == data.stamp) return;
   stamps[id] = data.stamp;

   /*
    * Obtém o nome do arquivo de log.
    */
   string filename = path;
   char str[10];
   sprintf(str, "/%03d.csv", id);
   filename += str;

   /*
    * Abre o arquivo e adiciona dados no final.
    * Campos separados por ';'
    */
   FILE *fp = fopen(filename.c_str(), "a");
   if(fp == NULL) return;

   fprintf(fp, "%d;%d;", id, data.stamp);
   if(data.pressao.valido)
      fprintf(fp, "%.2f", data.pressao.valor);
   fprintf(fp, ";");
   if(data.umidade.valido)
      fprintf(fp, "%.1f", data.umidade.valor);
   fprintf(fp, ";");
   if(data.temp.valido)
      fprintf(fp, "%.1f", data.temp.valor);
   else if(data.temp_alt.valido)
      fprintf(fp, "%.1f", data.temp_alt.valor);
   fprintf(fp, "\n");
   fclose(fp);
}
