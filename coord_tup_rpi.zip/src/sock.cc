
#include "sock.h"
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <string.h>
#include <stdexcept>
#include <errno.h>
using namespace std;

/* ==============================================
 *              Classe TCPSocket
 * ============================================== */
/**
 * Encerra conexão com o socket, caso ainda esteja aberto.
 */
void
TCPSocket::close()
{
   if(handler != -1)
    ::close(handler);
   handler = -1;
}

/**
 * Envia bytes através do socket.
 * @param buf Área com os dados a enviar.
 * @param size Tamanho da área em bytes.
 * @return Número de bytes enviados.
 */
int
TCPSocket::write(void *buf, int size)
{
   if(handler == -1) return 0;
   return ::write(handler, buf, size);
}

/**
 * Recebe bytes através do socket.
 * @param buf Área para receber os dados.
 * @param size Quantidade de bytes a receber (máximo).
 * @return Número de bytes recebidos.
 */
int
TCPSocket::read(void *buf, int size)
{
   int res;
   if(handler == -1) return 0;
   for(;;) {
      res = ::read(handler, buf, size);
      if(res >= 0) return res;
      if(errno == EINTR) continue;
      return 0;
   }
}

/**
 * Retorna o número de bytes disponíveis para leitura na fila de entrada.
 */
int
TCPSocket::read_length()
{
   if(handler == -1) return 0;
   int res;
   ioctl(handler, FIONREAD, &res);
   return res;
}

/**
 * Retorna o endereço IP no formato 0.0.0.0.
 */
char *
TCPSocket::get_address()
{
   inet_ntop(AF_INET, &addr.sin_addr.s_addr, c_addr, sizeof(c_addr));
   return c_addr;
}

/**
 * Destrutor. Somente fecha o socket, caso close() ainda não tenha sido chamado.
 */
TCPSocket::~TCPSocket()
{
   this->close();
}

/* ==============================================
 *               Classe TCPServer
 * ============================================== */

/**
 * Construtor.
 * Tenta associar o serviço na porta especificada.
 * @param port Porta desejada para o serviço.
 * @throws runtime_error caso a porta esteja sendo utilizada por outra aplicação.
 */
TCPServer::TCPServer(int port, int connections)
{
   /*
    * Abre socket no sistema operacional.
    */
   handler = socket(AF_INET, SOCK_STREAM, 0);
   if(handler < 0) throw runtime_error("Impossível criar socket");

   this->port = port;

   /*
    * Tenta associar com uma porta local.
    */
   memset(&addr, 0, sizeof(addr));
   addr.sin_family = AF_INET;
   addr.sin_port = htons(port);
   addr.sin_addr.s_addr = INADDR_ANY;

   int r = bind(handler, (struct sockaddr*)&addr, sizeof(addr));
   if(r != 0) {
      close();
      throw runtime_error("Impossível associar socket (WAIT_STATE?)");
   }

   /*
    * Coloca o socket no estado "Listen".
    */
   int res = ::listen(handler, connections);
   if(res < 0) throw runtime_error("Impossível entrar no estado listen.");
}

/**
 * Espera por uma conexão no serviço especificado.
 * @param conections Número máximo de conexões simultâneas.
 * @return Objeto TCPClient correspondente ao cliente conectado ou NULL em caso de erro.
 */
unique_ptr<TCPClient>
TCPServer::listen()
{
   struct sockaddr_in client_addr;
   socklen_t length = sizeof(client_addr);
   memset(&client_addr, 0, sizeof(client_addr));

   /*
    * Aceita conexão com o cliente, criando um novo objeto TCPClient.
    */
   int client_handler = accept(handler, (struct sockaddr*)&client_addr, &length);
   if(client_handler < 0) return nullptr;

   return unique_ptr<TCPClient>(new TCPClient(client_handler, &client_addr));
}

/* ==============================================
 *               Classe TCPClient
 * ============================================== */

/**
 * Construtor especial usado por TCPServer para uma nova conexão de entrada.
 * @param handler File-descriptor do socket a ser adotado.
 * @param addr Estrutura de endereçamento a ser adotada.
 */
TCPClient::TCPClient(int handler, struct sockaddr_in *addr)
{
   this->handler = handler;
   memcpy(&this->addr, addr, sizeof(struct sockaddr_in));
   port = addr->sin_port;
}

/**
 * Tenta conectar com o serviço TCP-IP especificado.
 * @param serv String com o endereço do serviço no formato 0.0.0.0.
 * @param port Porta TCP do serviço desejado.
 * @return true caso bem sucedido.
 */
bool
TCPClient::connect(char *serv, int port)
{
   /*
    * Traduz campo de endereço.
    */
   memset(&addr, 0, sizeof(addr));
   if(inet_pton(AF_INET, serv, &addr.sin_addr) != 1) return false;

   addr.sin_family = AF_INET;
   addr.sin_port = htons(port);

   handler = socket(AF_INET, SOCK_STREAM, 0);
   if(handler == -1) return false;
   if(::connect(handler, (struct sockaddr*)&addr, sizeof(addr)) == 0) return true;

   ::close(handler);
   handler = -1;
   return false;
}
