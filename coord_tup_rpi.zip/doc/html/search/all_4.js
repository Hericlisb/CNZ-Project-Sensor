var searchData=
[
  ['bat_5fsig',['bat_sig',['../struct_____p_a_c_k_e_d.html#a8424796c02803ceb3917f5ec15a253bb',1,'__PACKED']]],
  ['bateria',['bateria',['../structterminal__t.html#a1245f1603b2e78e0397d4888a09639e4',1,'terminal_t']]],
  ['bbreg0',['BBREG0',['../mrf24j40_8cc.html#afb13e8840d53ff354a154857e68caad7',1,'mrf24j40.cc']]],
  ['bbreg1',['BBREG1',['../mrf24j40_8cc.html#a20cb57e354cea1bb261e2c7e36829f80',1,'mrf24j40.cc']]],
  ['bbreg2',['BBREG2',['../mrf24j40_8cc.html#abc8629a2ad9d0c4cd02f6e777d221918',1,'mrf24j40.cc']]],
  ['bbreg3',['BBREG3',['../mrf24j40_8cc.html#ad32f633d7bbbd976bca5688789c58929',1,'mrf24j40.cc']]],
  ['bbreg4',['BBREG4',['../mrf24j40_8cc.html#afca132961c5869e8fb55b3861f3a879c',1,'mrf24j40.cc']]],
  ['bbreg5',['BBREG5',['../mrf24j40_8cc.html#aaf07ca2ad2f087124df7b249ecd2b780',1,'mrf24j40.cc']]],
  ['bbreg6',['BBREG6',['../mrf24j40_8cc.html#afd2fbebdba4de5a48540fe75c71da7be',1,'mrf24j40.cc']]],
  ['bistcr',['BISTCR',['../mrf24j40_8cc.html#a030d1d2438ce05e2d9de176cf997e0bd',1,'mrf24j40.cc']]],
  ['bm180_5fpressao',['bm180_pressao',['../struct_____p_a_c_k_e_d.html#a469806c13d5dedeadb49ed889295c057',1,'__PACKED']]],
  ['bm180_5ftemperatura',['bm180_temperatura',['../struct_____p_a_c_k_e_d.html#ae8c01162595c74ffd13ad137a36e6def',1,'__PACKED']]]
];
