var searchData=
[
  ['_5f_5fpacked',['__PACKED',['../struct_____p_a_c_k_e_d.html',1,'__PACKED'],['../scan_8cc.html#abe8996d3d985ee1529475443cc635bf1',1,'__PACKED():&#160;scan.cc'],['../vot_8cc.html#abe8996d3d985ee1529475443cc635bf1',1,'__PACKED():&#160;vot.cc']]],
  ['_5fconfigura',['_configura',['../main_8cc.html#a407d4cd03ebc63a63978e0bcb7089e18',1,'main.cc']]],
  ['_5frun',['_run',['../main_8cc.html#a2fe174d321b19d2997e2f144299cbe6b',1,'main.cc']]]
];
