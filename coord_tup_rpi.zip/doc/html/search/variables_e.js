var searchData=
[
  ['pan',['pan',['../struct_____p_a_c_k_e_d.html#a931baef26e2801133c7e07e524242c6c',1,'__PACKED']]],
  ['port',['port',['../class_t_c_p_socket.html#a6235e5b9a11c6ef2e8bbc8f28bb03666',1,'TCPSocket']]],
  ['port_5fto_5flisten',['port_to_listen',['../main_8cc.html#a64187779a97597dee9fdf19ec90795be',1,'main.cc']]],
  ['pressao',['pressao',['../structsensor__data__t.html#a5c05b54b42125973d55960963c95f545',1,'sensor_data_t']]]
];
