var searchData=
[
  ['add',['add',['../class_atomic_int.html#a865df415c7e0a3272549f7bcdafa4970',1,'AtomicInt']]],
  ['atomicint',['AtomicInt',['../class_atomic_int.html#a40742699137eaa258908d668e1fa0afe',1,'AtomicInt']]],
  ['atualiza_5ferro',['atualiza_erro',['../class_controle_vot.html#aac9a092fa606686ec28c4c096fee55cb',1,'ControleVot']]],
  ['atualiza_5fterminais',['atualiza_terminais',['../class_controle_vot.html#a97cd302081125d66c7146ba01b25f73e',1,'ControleVot']]]
];
