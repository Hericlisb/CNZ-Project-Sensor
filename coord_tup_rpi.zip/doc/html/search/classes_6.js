var searchData=
[
  ['scanner',['Scanner',['../class_scanner.html',1,'']]],
  ['sensor_5fdata_5ft',['sensor_data_t',['../structsensor__data__t.html',1,'']]],
  ['servidor',['Servidor',['../class_servidor.html',1,'']]],
  ['spi',['SPI',['../class_s_p_i.html',1,'']]]
];
