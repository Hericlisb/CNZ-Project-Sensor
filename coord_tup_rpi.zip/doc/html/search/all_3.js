var searchData=
[
  ['acktmout',['ACKTMOUT',['../mrf24j40_8cc.html#a66b340ed4709677d9e76d4f15e4600cd',1,'mrf24j40.cc']]],
  ['add',['add',['../class_atomic_int.html#a865df415c7e0a3272549f7bcdafa4970',1,'AtomicInt']]],
  ['addr',['addr',['../class_t_c_p_socket.html#ae6a3d76379f3d617e985bd101792fad3',1,'TCPSocket']]],
  ['am2301_5ftemperatura',['am2301_temperatura',['../struct_____p_a_c_k_e_d.html#a912a47a9ae0e1fb9b2cf6c24e98c532c',1,'__PACKED']]],
  ['am2301_5fumidade',['am2301_umidade',['../struct_____p_a_c_k_e_d.html#a3b97882d349ae17c427ed1a339a2e28d',1,'__PACKED']]],
  ['arquivo_5fsensores',['ARQUIVO_SENSORES',['../config_8inc_8php.html#af2554d65ae7215de72397ad55a35ec8e',1,'config.inc.php']]],
  ['arquivos',['arquivos',['../namespaceunifica.html#af670f3c1402e409c4f0a923315ef5bfe',1,'unifica']]],
  ['atomicint',['AtomicInt',['../class_atomic_int.html',1,'AtomicInt'],['../class_atomic_int.html#a40742699137eaa258908d668e1fa0afe',1,'AtomicInt::AtomicInt()']]],
  ['atualiza_5ferro',['atualiza_erro',['../class_controle_vot.html#aac9a092fa606686ec28c4c096fee55cb',1,'ControleVot']]],
  ['atualiza_5fterminais',['atualiza_terminais',['../class_controle_vot.html#a97cd302081125d66c7146ba01b25f73e',1,'ControleVot']]]
];
