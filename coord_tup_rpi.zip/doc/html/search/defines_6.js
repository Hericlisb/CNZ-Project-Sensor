var searchData=
[
  ['gateclk',['GATECLK',['../mrf24j40_8cc.html#a308fbf44a4d0931923e22ee20a5d9017',1,'mrf24j40.cc']]],
  ['gpio_5fr',['GPIO_R',['../mrf24j40_8cc.html#ad01380afba4f65706906cdf54c99889c',1,'mrf24j40.cc']]]
];
