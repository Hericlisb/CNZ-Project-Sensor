var searchData=
[
  ['habilitado',['habilitado',['../structterminal__t.html#a031a522eb34628e9806c16c167e35e27',1,'terminal_t']]],
  ['handler',['handler',['../class_t_c_p_socket.html#a652ff6574cd74cd8e6cfc1d91997b17a',1,'TCPSocket::handler()'],['../class_thread.html#a33f1a9a1e8b8797bb0ca17059f1c4dbc',1,'Thread::handler()']]]
];
