var searchData=
[
  ['data_5ft',['data_t',['../structdata__t.html',1,'']]],
  ['datalog',['Datalog',['../class_datalog.html',1,'']]]
];
