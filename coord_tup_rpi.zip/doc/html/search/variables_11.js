var searchData=
[
  ['temp',['temp',['../structsensor__data__t.html#a0e39fcbec20f189b4afbfcdb5e98cf87',1,'sensor_data_t']]],
  ['temp_5falt',['temp_alt',['../structsensor__data__t.html#a678590689fb7bbcebac28a4875bf2246',1,'sensor_data_t']]],
  ['tempo_5flog',['tempo_log',['../main_8cc.html#a2952a49daea0136bec74df78dc0f3f1c',1,'main.cc']]],
  ['terminais',['terminais',['../class_controle_vot.html#a3412cf5eea7aa8797b7d1f67dc2baa76',1,'ControleVot']]],
  ['terminated',['terminated',['../class_thread.html#ae8acc1f2a367e5be62b9d6d5bd3abbcb',1,'Thread']]],
  ['tipo',['tipo',['../struct_____p_a_c_k_e_d.html#a258ed299050c9d9e288021362987f7db',1,'__PACKED']]],
  ['ttl',['ttl',['../struct_____p_a_c_k_e_d.html#a46bf6f54d46aec3cf7851bee47bd95e4',1,'__PACKED']]]
];
