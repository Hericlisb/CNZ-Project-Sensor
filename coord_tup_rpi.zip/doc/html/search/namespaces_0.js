var searchData=
[
  ['unifica',['unifica',['../namespaceunifica.html',1,'']]]
];
