var searchData=
[
  ['pacon0',['PACON0',['../mrf24j40_8cc.html#a3128570387a4ddfd796886dabf26ec88',1,'mrf24j40.cc']]],
  ['pacon1',['PACON1',['../mrf24j40_8cc.html#a76fe8f525f64303726499b75b1af5a72',1,'mrf24j40.cc']]],
  ['pacon2',['PACON2',['../mrf24j40_8cc.html#ae058aeb59a04b88b23447568d184fe63',1,'mrf24j40.cc']]],
  ['pan',['pan',['../struct_____p_a_c_k_e_d.html#a931baef26e2801133c7e07e524242c6c',1,'__PACKED']]],
  ['panidh',['PANIDH',['../mrf24j40_8cc.html#a460454fa7eb4c39d5d05256626922a52',1,'mrf24j40.cc']]],
  ['panidl',['PANIDL',['../mrf24j40_8cc.html#a2d03831e7338dd2289d5d432c0e944cf',1,'mrf24j40.cc']]],
  ['port',['port',['../class_t_c_p_socket.html#a6235e5b9a11c6ef2e8bbc8f28bb03666',1,'TCPSocket']]],
  ['port_5fto_5flisten',['PORT_TO_LISTEN',['../config_8h.html#a4beb16a668deefa781d4267143693a57',1,'PORT_TO_LISTEN():&#160;config.h'],['../main_8cc.html#a64187779a97597dee9fdf19ec90795be',1,'port_to_listen():&#160;main.cc']]],
  ['pressao',['pressao',['../structsensor__data__t.html#a5c05b54b42125973d55960963c95f545',1,'sensor_data_t']]],
  ['processa_5fmensagem',['processa_mensagem',['../class_scanner.html#a1a55e371d25db73ba1fbd433e1f92d96',1,'Scanner::processa_mensagem()'],['../class_controle_vot.html#af5f2749beb541de0d1ca1baa463b663a',1,'ControleVot::processa_mensagem()']]],
  ['putc',['putc',['../class_s_p_i.html#a9664a31cff204d1a96275440aa933320',1,'SPI']]]
];
