var searchData=
[
  ['addr',['addr',['../class_t_c_p_socket.html#ae6a3d76379f3d617e985bd101792fad3',1,'TCPSocket']]],
  ['am2301_5ftemperatura',['am2301_temperatura',['../struct_____p_a_c_k_e_d.html#a912a47a9ae0e1fb9b2cf6c24e98c532c',1,'__PACKED']]],
  ['am2301_5fumidade',['am2301_umidade',['../struct_____p_a_c_k_e_d.html#a3b97882d349ae17c427ed1a339a2e28d',1,'__PACKED']]],
  ['arquivo_5fsensores',['ARQUIVO_SENSORES',['../config_8inc_8php.html#af2554d65ae7215de72397ad55a35ec8e',1,'config.inc.php']]],
  ['arquivos',['arquivos',['../namespaceunifica.html#af670f3c1402e409c4f0a923315ef5bfe',1,'unifica']]]
];
