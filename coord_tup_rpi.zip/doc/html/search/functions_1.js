var searchData=
[
  ['_5fconfigura',['_configura',['../main_8cc.html#a407d4cd03ebc63a63978e0bcb7089e18',1,'main.cc']]],
  ['_5frun',['_run',['../main_8cc.html#a2fe174d321b19d2997e2f144299cbe6b',1,'main.cc']]]
];
