var searchData=
[
  ['frame_5fbeacon_5ft',['frame_beacon_t',['../scan_8cc.html#a7179e8df33a17a41cac8c72bc7790f3d',1,'frame_beacon_t():&#160;scan.cc'],['../vot_8cc.html#a7179e8df33a17a41cac8c72bc7790f3d',1,'frame_beacon_t():&#160;vot.cc']]],
  ['frame_5fdata_5ft',['frame_data_t',['../scan_8cc.html#a3e124d2b4641f2f4fdc227b7fcc43775',1,'scan.cc']]],
  ['frame_5fpoke_5ft',['frame_poke_t',['../vot_8cc.html#aaa4cf76a8e7bfd7bb28ef0bb0b7da59c',1,'vot.cc']]],
  ['frame_5fstatus_5ft',['frame_status_t',['../vot_8cc.html#ace2594ec58a5976afbf5c159030312d0',1,'vot.cc']]]
];
