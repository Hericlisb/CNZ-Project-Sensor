var searchData=
[
  ['close',['close',['../class_t_c_p_socket.html#ae64f7db5484a7f057446ac3c906629c0',1,'TCPSocket']]],
  ['connect',['connect',['../class_t_c_p_client.html#a2493c58f09058f1d8b53f9183596d8e4',1,'TCPClient']]],
  ['controlevot',['ControleVot',['../class_controle_vot.html#aa9ab123efb28c3c434bd033ca5b478a9',1,'ControleVot']]]
];
