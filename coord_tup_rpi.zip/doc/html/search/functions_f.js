var searchData=
[
  ['radio_5fcallback',['radio_callback',['../vot_8cc.html#a0b132d0f0b76b460bd9dd44cd0c7de8a',1,'vot.cc']]],
  ['read',['read',['../class_g_p_i_o.html#a8314e24d6dc717f8d83c9979f1a84c72',1,'GPIO::read()'],['../class_t_c_p_socket.html#af7fbc375496959b9b66899936f1536e5',1,'TCPSocket::read()'],['../class_s_p_i.html#a5c9c580c210c87bd06b65e9d5571af75',1,'SPI::read()']]],
  ['read_5flength',['read_length',['../class_t_c_p_socket.html#a7f3073cbe1ac862427d1ab2f1de0b925',1,'TCPSocket']]],
  ['recv',['recv',['../class_m_r_f24.html#af849daa2a928c2e1a0afd7ed74d6e084',1,'MRF24']]],
  ['redirect_5fto_5ferror',['redirect_to_error',['../get__csv_8php.html#afaf7c47fde45ef89de7d65f04347aabf',1,'get_csv.php']]],
  ['redirect_5fto_5fno_5fdata',['redirect_to_no_data',['../get__csv_8php.html#a149e5371c99a3979e753e0db3d662ef5',1,'get_csv.php']]],
  ['reset',['reset',['../class_g_p_i_o.html#ac07b8ccefa9a990b153da9d7ebb7d7de',1,'GPIO::reset()'],['../class_m_r_f24.html#a70e551cb3d5a4f4e7a332173c5dc4677',1,'MRF24::reset()']]],
  ['run',['run',['../class_my_timer.html#aae38edfaa8ba44b3c533be7bac43ea3a',1,'MyTimer::run()'],['../class_servidor.html#a90fa5e4d7b272a3bf5e448f664afefe1',1,'Servidor::run()'],['../class_datalog.html#a55f9ebe0c189720f0d230f8d2637b0bc',1,'Datalog::run()'],['../class_thread_message.html#a2dab26baad88db827b506562de044fb9',1,'ThreadMessage::run()'],['../class_scanner.html#a659098fd0de71bafbdd8356ff90f9299',1,'Scanner::run()'],['../class_thread.html#aae90dfabab3e1776cf01a26e7ee3a620',1,'Thread::run()'],['../class_controle_vot.html#a9533bcbcd974551ee82e2e0b86d96049',1,'ControleVot::run()']]]
];
