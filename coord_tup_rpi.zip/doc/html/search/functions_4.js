var searchData=
[
  ['datalog',['Datalog',['../class_datalog.html#a9837eff27da7e6574674463af3b67273',1,'Datalog']]]
];
