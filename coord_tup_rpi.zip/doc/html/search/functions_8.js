var searchData=
[
  ['habilita_5fterminal',['habilita_terminal',['../class_controle_vot.html#a66ffdd967e7d4011f3f856a0d57d3ec2',1,'ControleVot']]]
];
