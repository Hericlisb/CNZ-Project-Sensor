var searchData=
[
  ['wait',['wait',['../class_g_p_i_o.html#ab3c9275ebade1c1513caa4fee56129cd',1,'GPIO']]],
  ['write',['write',['../class_t_c_p_socket.html#a5efbf51111ac61e1dae728f218c0040e',1,'TCPSocket::write()'],['../class_s_p_i.html#a0f906cccbccd2fa9b4723c6c581ecf69',1,'SPI::write()']]]
];
