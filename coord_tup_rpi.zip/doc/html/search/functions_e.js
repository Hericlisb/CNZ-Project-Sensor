var searchData=
[
  ['processa_5fmensagem',['processa_mensagem',['../class_scanner.html#a1a55e371d25db73ba1fbd433e1f92d96',1,'Scanner::processa_mensagem()'],['../class_controle_vot.html#af5f2749beb541de0d1ca1baa463b663a',1,'ControleVot::processa_mensagem()']]],
  ['putc',['putc',['../class_s_p_i.html#a9664a31cff204d1a96275440aa933320',1,'SPI']]]
];
