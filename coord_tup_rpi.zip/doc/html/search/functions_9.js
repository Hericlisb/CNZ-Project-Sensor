var searchData=
[
  ['inicia_5fvotacao',['inicia_votacao',['../class_controle_vot.html#a7754a5c36888d07cf811089df8fe8f89',1,'ControleVot']]],
  ['init',['init',['../class_m_r_f24.html#a691a037c305c88c3ae0f58ee06c92563',1,'MRF24']]]
];
