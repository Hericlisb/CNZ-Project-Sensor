var searchData=
[
  ['datalog_2ephp',['datalog.php',['../datalog_8php.html',1,'']]]
];
