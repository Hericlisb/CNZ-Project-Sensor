var searchData=
[
  ['ultimo',['ultimo',['../structterminal__t.html#a4242c9e535faf45b83d3cf3d166bf2c9',1,'terminal_t']]],
  ['umidade',['umidade',['../structsensor__data__t.html#a119dc292628e6ff06b18ef300d176d02',1,'sensor_data_t']]],
  ['unifica',['unifica',['../namespaceunifica.html',1,'']]],
  ['unifica_2epy',['unifica.py',['../unifica_8py.html',1,'']]],
  ['unlock',['unlock',['../class_mutex.html#a546a5b797ba29959357586aa2b3740a8',1,'Mutex']]]
];
