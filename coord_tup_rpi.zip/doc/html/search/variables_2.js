var searchData=
[
  ['bat_5fsig',['bat_sig',['../struct_____p_a_c_k_e_d.html#a8424796c02803ceb3917f5ec15a253bb',1,'__PACKED']]],
  ['bateria',['bateria',['../structterminal__t.html#a1245f1603b2e78e0397d4888a09639e4',1,'terminal_t']]],
  ['bm180_5fpressao',['bm180_pressao',['../struct_____p_a_c_k_e_d.html#a469806c13d5dedeadb49ed889295c057',1,'__PACKED']]],
  ['bm180_5ftemperatura',['bm180_temperatura',['../struct_____p_a_c_k_e_d.html#ae8c01162595c74ffd13ad137a36e6def',1,'__PACKED']]]
];
