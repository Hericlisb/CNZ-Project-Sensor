var searchData=
[
  ['saida',['saida',['../namespaceunifica.html#a7d5b7a580f62df6931df9e056d74dfa7',1,'unifica']]],
  ['seq',['seq',['../struct_____p_a_c_k_e_d.html#a81fdaa5aed3f806a45658fa799aa9a1b',1,'__PACKED']]],
  ['sinal',['sinal',['../structterminal__t.html#a53379c2877b42e5cb0d5bef3fe54eba6',1,'terminal_t']]],
  ['source',['source',['../struct_____p_a_c_k_e_d.html#af79e40a17a6a28ae96023b9d73162161',1,'__PACKED']]],
  ['stamp',['stamp',['../structsensor__data__t.html#aa904a84d83e65e6305011e6a38497f7a',1,'sensor_data_t']]],
  ['status',['status',['../struct_____p_a_c_k_e_d.html#a5a95253d23e144862e3dbcc918d7d3b2',1,'__PACKED']]]
];
