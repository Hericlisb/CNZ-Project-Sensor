var searchData=
[
  ['valido',['valido',['../structdata__t.html#a107cc99732bd32d288902f45a6504525',1,'data_t']]],
  ['valor',['valor',['../structdata__t.html#ab1ed9bce6d065b306d9560d515a90dac',1,'data_t']]],
  ['vid',['vid',['../struct_____p_a_c_k_e_d.html#ad73bb77ee1d21ba33c82e1e527fd8733',1,'__PACKED']]]
];
