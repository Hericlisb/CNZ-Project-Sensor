var searchData=
[
  ['edge',['edge',['../class_g_p_i_o.html#ab3e8a5ac9c20c58c0d1b3f03c289f803',1,'GPIO']]],
  ['encerra_5fvotacao',['encerra_votacao',['../class_controle_vot.html#ad998c6c39cc5ba38b9cdf17b0be9b634',1,'ControleVot']]]
];
