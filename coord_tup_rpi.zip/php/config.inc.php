
<?php
define("ARQUIVO_SENSORES", "/var/sensores/last.csv");
define("MAX_ID", 127);
define("LOG_DIR", "/var/sensores/log");
 ?>