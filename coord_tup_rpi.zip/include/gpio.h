
#ifndef __GPIO_H__
#define __GPIO_H__

#include <stdint.h>
#include <string>
using namespace std;

class GPIO {
public:
   GPIO(int port, bool output=false, int delay=0);
   virtual ~GPIO();
   void edge(string v);
   void set();
   void reset();
   void toggle();
   bool read();
   bool wait(int timeout=-1);
   void operator=(bool v);
   void operator=(int v);
   operator bool();
   operator int();

private:
   int fd;
   int port;
   int delay;
   bool output;
   bool current;
};

#endif
