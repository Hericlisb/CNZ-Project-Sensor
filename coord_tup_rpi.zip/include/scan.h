
#ifndef __SCAN_H__
#define __SCAN_H__

#include "thread.h"
#include "mrf24j40.h"
#include <stdint.h>
#include <time.h>
#include <map>
#include <memory>
using namespace std;

typedef struct {
   bool valido;
   float valor;
} data_t;

typedef struct {
   int id;
   data_t pressao;
   data_t umidade;
   data_t temp;
   data_t temp_alt;
   uint8_t next;
   uint8_t lqi;
   time_t stamp;
} sensor_data_t;

class Scanner: public Thread {
public:
   Scanner(shared_ptr<MRF24> radio, shared_ptr<GPIO> led=nullptr);

   bool get_data(int id, sensor_data_t& data);
   virtual void run() override;
   void processa_mensagem();

   map<int, sensor_data_t>dados;

private:
   void envia_beacon();
   void radio_reset();
   void testa_timeouts();
   shared_ptr<MRF24> radio;
   shared_ptr<GPIO> led;
   uint8_t sequencia;
   int timeout;
   Mutex mutex;
};

#endif
