
#ifndef __SOCK_H__
#define __SOCK_H__

#include <netinet/in.h>
#include <memory>
using namespace std;

class TCPServer;

class TCPSocket {
public:
   int write(void *buf, int size);
   int read(void *buf, int size);
   int read_length();
   int get_port() { return port; };
   char *get_address();
   void close();
   TCPSocket() { };
   virtual ~TCPSocket();

protected:
   struct sockaddr_in addr;
   int handler = -1;
   int port;
   char c_addr[20];
};

class TCPClient: public TCPSocket {
public:
   TCPClient(): TCPSocket() { };
   TCPClient(int handler, struct sockaddr_in *addr);
   bool connect(char *serv, int port);
};

class TCPServer: public TCPSocket {
public:
   TCPServer(int port, int connections=5);
   unique_ptr<TCPClient> listen();
};


#endif
