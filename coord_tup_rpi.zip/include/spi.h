
#ifndef __SPI_H__
#define __SPI_H__

#include <string>
#include <stdint.h>
using namespace std;

class SPI {
public:
   SPI(string dev, uint32_t clk=2000000);
   virtual ~SPI();
   bool transfer(uint8_t *tx, uint8_t *rx, uint8_t size);
   void write(uint8_t *tx, int size);
   int read(uint8_t *rx, int size);
   void putc(uint8_t c);
   int getc();

private:
   string dev;
   uint32_t clk;
   int fd;
};

#endif
