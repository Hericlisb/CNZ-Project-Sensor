
#ifndef __CONFIG_H__
#define __CONFIG_H__

//#define DEBUG

#define MAX_ID                127

#define PORT_TO_LISTEN        50505
#define LOG_DIR               "/var/sensores/log"
#define TEMPO_LOG             900                        // quinze minutos

/*
 * Configurações para host.cc
 */
#define TEMPO_SCAN            30                         // 30s.
#define TMP_FILE              "./sens.tmp"
#define OUT_FILE              "/var/sensores/last.csv"

/*
 * Configurações para scan.cc
 */
#define TEMPO_BEACON          5000000                    // 5s.
#define TIMEOUT_RADIO         24                         // 24 * 5s = 2 minutos
#define TIMEOUT_SENSOR        60                         // 60s
#define NETWORK_ID            0x3c                       // identificador da rede dos sensores
#define CHANNEL_NR            19                         // canal de comunicação (11-26)

/*
 * Configurações do hardware
 */
#define LED_GPIO              18
#define MRF_DEV               "/dev/spidev0.0"
#define CS_PIN                25
#define RST_PIN               24
#define IRQ_PIN               23

#endif
