#ifndef __MRF24J40_H__
#define __MRF24J40_H__

#include "gpio.h"
#include "spi.h"
#include <string>
#include <stdint.h>
#include <unistd.h>
#include "thread.h"
#include <functional>
using namespace std;

class ThreadMessage: public Thread {
public:
   function<void(void)> callback;
   ThreadMessage(function<void(void)>fn, GPIO *irq) {
      this->callback = fn;
      this->irq = irq;
   }
   virtual void run(void) override {
      while(!terminated) {
         if(irq->wait()) {
            if(callback != nullptr) callback();
         }
      }
   }

private:
   GPIO *irq;
};

class MRF24 {
public:
   MRF24(string device);

   void send(uint8_t *pckt, int size, int header=0);
   int recv(uint8_t *pckt, int size);
   void reset();
   void init(bool usa_lna=false, bool turbo=false);
   void set_channel(uint8_t ch);
   void set_power(uint8_t pw);
   void set_message_callback(function<void(void)> fn);

   int lqi;
   int rssi;

private:
   SPI spi;
   GPIO cs;
   GPIO rst;
   GPIO irq;
   ThreadMessage *aux = nullptr;
   Mutex mutex;

   void write_short(uint8_t reg, uint8_t val);
   uint8_t read_short(uint8_t reg);
   void write_long(uint16_t reg, uint8_t val);
   uint8_t read_long(uint16_t reg);
};

#endif
