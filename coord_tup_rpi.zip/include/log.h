
#ifndef __LOG_H__
#define __LOG_H__

#include "thread.h"
#include "scan.h"
#include "time.h"

#include <map>
#include <string>
using namespace std;

class Datalog: public Thread {
public:
   Datalog(shared_ptr<Scanner> s, string logdir, int tempo=30);
   virtual void run() override;
   void set_tempo(int t) { if(t >= 10) tempo = t; };
   void log_now();
   void log_item(sensor_data_t& data);

private:
   shared_ptr<Scanner> scanner;
   int tempo;
   string path;
   map<int, time_t> stamps;
};


#endif
