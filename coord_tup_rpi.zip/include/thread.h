
#ifndef __THREAD_H__
#define __THREAD_H__

#include <pthread.h>

class Thread {
public:
   Thread(bool free_on_terminate=false);
   virtual ~Thread();
   virtual void run()=0;
   pthread_t handler;
   bool free_on_terminate;
   void signal(int n);
   void terminate() { terminated = true; };
   static void join(Thread& t);
   static void yield();
   static bool sleep(int n);
   static bool sleep_ms(int n);
   static bool sleep_us(int n);

protected:
   bool terminated = false;
};

class Mutex {
public:
   Mutex();
   virtual ~Mutex();
   void lock();
   void unlock();

private:
   pthread_mutex_t mtx;
};

class AtomicInt {
public:
   AtomicInt(int n=0);
   void set(int v);
   int get();
   int add(int v);
   int sub(int v);

private:
   Mutex mutex;
   int val;
};

#endif
