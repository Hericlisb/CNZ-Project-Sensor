
#ifndef __HOST_H__
#define __HOST_H__

#include "scan.h"
#include "sock.h"
#include "thread.h"
#include <functional>
#include <stdio.h>
#include <list>
using namespace std;

class Servidor;

class MyTimer: public Thread {
public:
   MyTimer(int interval, function<void(void)> fn);
   void run() override;
private:
   function<void(void)> callback;
   int tempo;
};

class Servidor: public Thread {
public:
   Servidor(shared_ptr<Scanner> s, int port=50505);
   virtual ~Servidor();
   void send_data();
   void run() override;

private:
   MyTimer timer;
   TCPServer sckt;
   list<unique_ptr<TCPClient>> clientes;

   shared_ptr<Scanner> scanner;
   FILE *output;
   void send_all(int id, sensor_data_t& dados);
};


#endif
