
from pdfrw import PdfReader, PdfWriter
import os

saida = PdfWriter()

arquivos = [ x for x in os.listdir('.') if x.endswith('.pdf') ]
arquivos.sort()
for arquivo in arquivos:
    saida.addpages(PdfReader(arquivo).pages)

saida.write('placa.pdf')


